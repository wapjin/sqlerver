
class mysql:
    host="172.16.1.121"
    user="sqluser"
    passwd="sqlpasswd"
    bsdata="sqluser"
    port=3306
